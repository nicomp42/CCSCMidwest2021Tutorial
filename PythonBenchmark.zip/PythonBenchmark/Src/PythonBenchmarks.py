'''
@author: nicomp

'''
import time
# Add items to a List object
limit = 200000000
start_time = time.time()
i = 0
myList = []
while (i < limit):
    i = i + 1
    myList.append(i)
    
print("--- %s seconds ---" % (time.time() - start_time))
    
# Add items to a List object with a different type of loop
limit = 200000000
start_time = time.time()
i = 0
myList = []
for i in range(0,limit):
    myList.append(i)
    
print("--- %s seconds ---" % (time.time() - start_time))

print("Done")
