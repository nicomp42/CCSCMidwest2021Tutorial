import java.util.ArrayList;

public class JavaBenchmarks {

	public static void main(String[] args) {
		
		int limit = 200000000;
		ArrayList<Integer> myArrayList = new ArrayList<Integer>();
		final long startTime = System.currentTimeMillis();
		for (int i = 0; i < limit; i++) {
			myArrayList.add(i);
		}
		final long endTime = System.currentTimeMillis();

		System.out.println("Total execution time: " + (endTime - startTime)/1000. + " seconds.");
		
	}

}
